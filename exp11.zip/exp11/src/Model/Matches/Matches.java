package Model.Matches;

import java.util.ArrayList;
public class Matches extends Game {
    private static int match_count = 0;
    private int match_ID;
    private String venue;
    private String match_duration;
    private String match_date;

    int match_sea_count = 0;
    ArrayList<String> matchSeasons = new ArrayList<>();

    public static int getMatch_count() {
        return match_count;
    }

    public Matches() {
        match_count++;
        this.setMatch_ID(match_count);
    }

    public Matches(String venue, String match_duration, String match_date, String type) {
        match_count++;
        this.setMatch_ID(match_count);
        this.setVenue(venue);
        this.setMatch_duration(match_duration);
        this.setMatch_date(match_date);
        this.setSportsType(type);
    }

    public Matches(int match_id, String venue, String match_duration, String match_date, String type) {
        match_count++;
        this.setMatch_ID(match_id);
        this.setVenue(venue);
        this.setMatch_duration(match_duration);
        this.setMatch_date(match_date);
        this.setSportsType(type);
    }

    public void setMatch_ID(int match_ID) {
        this.match_ID = match_ID;
    }

    public void setMatch_duration(String match_duration) {
        this.match_duration = match_duration;
    }

    public void setVenue(String venue) {
        this.venue = venue;
    }

    public void setMatch_date(String match_date) {
        this.match_date = match_date;
    }

    public int getMatch_ID() {
        return match_ID;
    }

    public String getMatch_duration() {
        return match_duration;
    }

    public String getVenue() {
        return venue;
    }

    public String getMatch_date() {
        return match_date;
    }

    public void display() {
        System.out.println("Match ID: " + getMatch_ID());
        System.out.println("Venue: " + getVenue());
        System.out.println("Match Duration: " + getMatch_duration());
        System.out.println("Match Date: " + getMatch_date());
        System.out.println("Game: " + getSportsTitle());
        System.out.println("Game Type: " + getSportsType());
    }

    public static void setMatch_count(int match_count) {
        Matches.match_count = match_count;
    }

    public int getMatch_sea_count() {
        return match_sea_count;
    }
    public void setMatch_sea_count(int match_sea_count) {
        this.match_sea_count = match_sea_count;
    }
    public void addMatchSeason(String matchSeason) {
        System.out.println("Adding Match Season");
        matchSeasons.add(matchSeason);
        setMatch_sea_count(getMatch_sea_count()+1);
        System.out.println("Match Season set Successfully");
    }

    public void displayMatchSeason() {
        for(int i =0; i< matchSeasons.size();i++)
        {
            System.out.println(matchSeasons.get(i));
        }
    }
    public void removeMatchSeason(int matchSeason) {
        if (getMatch_sea_count()>1)
        {
            System.out.println("Removing Match Season");
            matchSeasons.remove(matchSeason);
            System.out.println("Removing Match Season");
            setMatch_sea_count(getMatch_sea_count()-1);
        }
        else {
            System.out.println("Match Season is Empty!!");
        }
    }
}