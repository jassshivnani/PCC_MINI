package Model.Matches;

import Model.Displayable;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;

public class manageMatches extends FileHandlingMatch implements Displayable {
    ArrayList < Matches > match = new ArrayList < > ();
    ObjectMapper objectMapper = new ObjectMapper();

    private int linesBeingDisplayed;
    private int firstLineIndex;
    int lastLineIndex;
    int highlightedLine;

    public manageMatches() {
        readMatchJsonFile("src/Model/Matches/Matches.json");
    }

    public ArrayList < Matches > readMatchJsonFile(String file_path) {
        try {
            JsonNode rootNode = objectMapper.readTree(new File(file_path));

            if (rootNode.isArray()) {
                for (JsonNode node: rootNode) {
                    int match_id = node.get("match_ID").asInt();
                    String venue = node.get("venue").asText();
                    String match_duration = node.get("match_duration").asText();
                    String match_date = node.get("match_date").asText();
                    String type = node.get("sportsType").asText();
                    Matches match1 = new Matches(match_id, venue, match_duration, match_date, type);
                    match.add(match1);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return match;
    }

    @Override
    public void writeMatchJsonFile(String file_path, String match) throws IOException {

    }

    public void writeMatchJsonFile(String file_path, ArrayList < Matches > match) throws IOException {
        objectMapper.writeValue(Paths.get(file_path).toFile(), match);
    }

    public void setGamesTable(ArrayList < Matches > match) {
        this.match = match;
    }
    public ArrayList < String > getHeaders() {
        ArrayList < String > headers = new ArrayList < > ();
        headers.add("Match ID");
        headers.add("Venue");
        headers.add("Duration");
        headers.add("Date");
        headers.add("Type");
        return headers;
    }
    @Override
    public ArrayList < String > getLine(int line) {
        ArrayList < String > game_details = new ArrayList < String > ();

        game_details.add(String.valueOf(match.get(line).getMatch_ID()));
        game_details.add(match.get(line).getVenue());
        game_details.add(match.get(line).getMatch_date());
        game_details.add(match.get(line).getMatch_duration());
        game_details.add(match.get(line).getSportsType());

        return game_details;
    }

    @Override
    public ArrayList < ArrayList < String >> getLines(int firstLine, int lastLine) {
        ArrayList < ArrayList < String >> matches_subset = new ArrayList < > ();

        for (int i = firstLine; i <= lastLine; i++) {
            matches_subset.add(getLine(i));
        }
        return matches_subset;
    }

    @Override
    public int getFirstLineToDisplay() {
        return firstLineIndex;
    }

    @Override
    public int getLineToHighlight() {
        return highlightedLine;
    }

    @Override
    public int getLastLineToDisplay() {
        setLastLineToDisplay(getFirstLineToDisplay() + getLinesBeingDisplayed() - 1);
        return lastLineIndex;
    }

    @Override
    public int getLinesBeingDisplayed() {
        return linesBeingDisplayed;
    }

    @Override
    public void setFirstLineToDisplay(int firstLine) {
        this.firstLineIndex = firstLine;
    }

    @Override
    public void setLineToHighlight(int highlightedLine) {
        this.highlightedLine = highlightedLine;
    }

    @Override
    public void setLastLineToDisplay(int lastLine) {
        this.lastLineIndex = lastLine;
    }

    @Override
    public void setLinesBeingDisplayed(int numberOfLines) {
        this.linesBeingDisplayed = numberOfLines;
    }
    public ArrayList getTable() {
        return match;
    }
}