package Model.Matches;
public interface MatchDesc {
    void addMatchSeason(String matchSeason);
    void removeMatchSeason(int matchSeason);
    void displayMatchSeason();
}