package Model.Matches;

import java.io.IOException;
import java.util.ArrayList;


public abstract class FileHandlingMatch {
    protected abstract ArrayList<Matches> readMatchJsonFile(String file_path);
    public abstract void writeMatchJsonFile(String file_path, String match) throws IOException;
}