package Model.Matches;

public class Game {
    private String sportsTitle;
    private String sportsType;

    int game_id;

    public int getGame_id() {
        return game_id;
    }

    public void setGame_id(int game_id) {
        this.game_id = game_id;
    }

    public Game() {
    }

    public Game(String sportsTitle, String sportsType, String venue, int year) {
        this.setSportsTitle(sportsTitle);
        this.setSportsType(sportsType);
    }
    public Game(int game_id,String sportsTitle, String sportsType) {
        this.setGame_id(game_id);
        this.setSportsTitle(sportsTitle);
        this.setSportsType(sportsType);
    }

    public void setSportsTitle(String sportsTitle) {
        this.sportsTitle = sportsTitle;
    }

    public void setSportsType(String sportsType) {
        this.sportsType = sportsType;
    }

    public String getSportsTitle() {
        return sportsTitle;
    }

    public String getSportsType() {
        return sportsType;
    }

    public void display() {
        System.out.println("Sports Title: " + getSportsTitle());
        System.out.println("Sports Type: " + getSportsType());
    }
}