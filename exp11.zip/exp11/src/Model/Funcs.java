package Model;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
public class Funcs {

    /**
     * Checks if the given date string is in a valid format (dd/MM/yyyy).
     * @param dateStr The date string to be validated.
     * @return true if the date string is valid, false otherwise.
     */
    public static boolean isValidDate(String dateStr) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        try {
            LocalDate.parse(dateStr, formatter);
            return true; // Valid date
        } catch (DateTimeParseException e) {
            return false; // Invalid date
        }
    }
}