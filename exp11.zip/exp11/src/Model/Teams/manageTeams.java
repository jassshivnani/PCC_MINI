package Model.Teams;

import Model.Displayable;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;

public class manageTeams extends FileHandlingTeams implements Displayable {
    ArrayList<Teams> teams = new ArrayList<>();
    ObjectMapper objectMapper = new ObjectMapper();
    private int linesBeingDisplayed;
    private int firstLineIndex;
    int lastLineIndex;
    int highlightedLine;

    public manageTeams() {
        readTeamsJsonFile("src/Model/Teams/Teams.json");
    }

    @Override
    public ArrayList<Teams> readTeamsJsonFile(String file_path) {
        try {
            JsonNode rootNode = objectMapper.readTree(new File(file_path));

            // Iterate through JSON array
            if (rootNode.isArray()) {
                for (JsonNode node : rootNode) {
                    int team_id = node.get("team_id").asInt();
                    String team_name = node.get("team_name").asText();
                    String coach = node.get("coach").asText();
                    int founded_year = node.get("founded_year").asInt();
                    String Country = node.get("Country").asText();
                    Teams t_temp = new Teams(team_id, team_name, coach, founded_year, Country);
                    teams.add(t_temp);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return teams;
    }

    @Override
    public void writeTeamsJsonFile(String file_path, ArrayList<Teams> teams) throws IOException {
        objectMapper.writeValue(Paths.get(file_path).toFile(), teams);
    }

    public ArrayList<String> getHeaders() {
        ArrayList<String> headers = new ArrayList<String>();
        headers.add("Team Id");
        headers.add("Team Name");
        headers.add("Team Coach");
        headers.add("Team Founded Year");
        headers.add("Team Country");
        return headers;
    }

    @Override
    public ArrayList<String> getLine(int line) {
        ArrayList<String> course_details = new ArrayList<String>();

        // Check if teams is empty or if line is out of bounds
        if (!teams.isEmpty() && line < teams.size()) {
            course_details.add(String.valueOf(teams.get(line).getTeam_id()));
            course_details.add(teams.get(line).getTeam_name());
            course_details.add(teams.get(line).getCoach());
            course_details.add(String.valueOf(teams.get(line).getFounded_year()));
            course_details.add(teams.get(line).getCountry());
        }

        return course_details;
    }

    @Override
    public ArrayList<ArrayList<String>> getLines(int firstLine, int lastLine) {
        ArrayList<ArrayList<String>> course_subset = new ArrayList<ArrayList<String>>();

        // Check if teams is empty
        if (!teams.isEmpty()) {
            for (int i = firstLine; i <= lastLine && i < teams.size(); i++) {
                course_subset.add(getLine(i));
            }
        }

        return course_subset;
    }

    @Override
    public int getFirstLineToDisplay() {
        return firstLineIndex;
    }

    @Override
    public int getLineToHighlight() {
        return highlightedLine;
    }

    @Override
    public int getLastLineToDisplay() {
        setLastLineToDisplay(getFirstLineToDisplay()+getLinesBeingDisplayed() - 1);
        return lastLineIndex;
    }

    @Override
    public int getLinesBeingDisplayed() {
        return linesBeingDisplayed;
    }

    @Override
    public void setFirstLineToDisplay(int firstLine) {
        this.firstLineIndex = firstLine;
    }

    @Override
    public void setLineToHighlight(int highlightedLine) {
        this.highlightedLine = highlightedLine;
    }

    @Override
    public void setLastLineToDisplay(int lastLine) {
        this.lastLineIndex = lastLine;
    }

    @Override
    public void setLinesBeingDisplayed(int numberOfLines) {
        this.linesBeingDisplayed = numberOfLines;
    }

    public ArrayList<Teams> getTable() {
        return teams;
    }
}

