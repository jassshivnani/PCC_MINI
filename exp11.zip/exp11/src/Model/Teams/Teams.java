package Model.Teams;
public class Teams {

    private static int teams_count = 0;
    int team_id;
    String team_name;
    String coach;
    int founded_year;
    String Country;

    public static int getTeams_count() {
        return teams_count;
    }
    public Teams() {
        teams_count++;
        this.setTeam_id(teams_count);
    }

    public Teams(String team_name, String coach, int founded_year, String Country) {
        teams_count++;
        this.setTeam_id(teams_count);
        this.setTeam_name(team_name);
        this.setCoach(coach);
        this.setFounded_year(founded_year);
        this.setCountry(Country);
    }

    public Teams(int team_id, String team_name, String coach, int founded_year, String Country) {
        teams_count++;
        this.setTeam_id(team_id);
        this.setTeam_name(team_name);
        this.setCoach(coach);
        this.setFounded_year(founded_year);
        this.setCountry(Country);
    }

    public void setTeam_id(int team_id) {
        this.team_id = team_id;
    }

    public void setTeam_name(String team_name) {
        this.team_name = team_name;
    }

    public void setCoach(String coach) {
        this.coach = coach;
    }

    public void setFounded_year(int founded_year) {
        this.founded_year = founded_year;
    }

    public void setCountry(String Country) {
        this.Country = Teams.this.Country;
    }
    public int getTeam_id() {
        return team_id;
    }

    public String getTeam_name() {
        return team_name;
    }

    public String getCoach() {
        return coach;
    }

    public int getFounded_year() {
        return founded_year;
    }

    public String getCountry() {
        return coach;
    }

    public void display() {
        System.out.println("Team Id: " + getTeam_id());
        System.out.println("Team Name: " + getTeam_name());
        System.out.println("Coach: " + getCoach());
        System.out.println("Founded year: " + getFounded_year());
        System.out.println("Country: " + getCountry());
    }
}