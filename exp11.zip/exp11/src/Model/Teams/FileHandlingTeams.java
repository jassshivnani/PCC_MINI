package Model.Teams;

import Model.Matches.Matches;

import java.io.IOException;
import java.util.ArrayList;

public abstract class FileHandlingTeams {
    protected abstract ArrayList<Teams> readTeamsJsonFile(String file_path);
    protected abstract void writeTeamsJsonFile(String file_path, ArrayList<Teams> teams) throws IOException;
}
