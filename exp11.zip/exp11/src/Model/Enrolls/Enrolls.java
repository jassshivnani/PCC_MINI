package Model.Enrolls;
import Model.Matches.Matches;
import Model.Matches.Matches.*;
import Model.Teams.Teams;
import Model.Teams.Teams.*;
public class Enrolls {
    Teams t_temp;
    Matches m_temp;
    String enroll_date;
    int match_entry_fees;
    public Enrolls(Teams s, Matches c, String c_date, int fees) {
        setS_temp(s);
        setC_temp(c);
        setEnroll_date(c_date);
        setMatch_entry_fees(fees);
    }
    public void setS_temp(Teams t_temp) {
        this.t_temp = t_temp;
    }
    public void setC_temp(Matches m_temp) {
        this.m_temp = m_temp;
    }
    public void setEnroll_date(String enroll_date) {
        this.enroll_date = enroll_date;
    }
    public void setMatch_entry_fees(int match_entry_fees) {
        this.match_entry_fees = match_entry_fees;
    }
    public Teams getS_temp() {
        return t_temp;
    }
    public Matches getC_temp() {
        return Enrolls.this.m_temp;
    }
    public String getEnroll_date() {
        return enroll_date;
    }
    public int getMatch_entry_fees() {
        return match_entry_fees;
    }
}