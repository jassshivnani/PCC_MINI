package Model.Enrolls;
public class ValidDateException extends Exception {

    //Constructor for ValidDateException class.
    public ValidDateException(String message) {
        super(message);
    }
}