package Model.Enrolls;
import Model.Matches.*;
import Model.Matches.manageMatches;
import Model.Displayable;
import Model.Matches.Matches;
import Model.Teams.*;
import Model.Teams.manageTeams;
import Model.Teams.Teams;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
public class manageEnrolls extends FileHandlingEnrolls implements Displayable {
    ArrayList < Matches > matches = new ArrayList < Matches > ();

    ArrayList < Teams > teams = new ArrayList < Teams > ();

    ArrayList < Enrolls > enrollment_data = new ArrayList < Enrolls > ();

    ObjectMapper objectMapper = new ObjectMapper();

    private int linesBeingDisplayed;
    private int firstLineIndex;
    int lastLineIndex;
    int highlightedLine;

    public manageEnrolls() {
        manageMatches ms1 = new manageMatches();
        matches = ms1.getTable();
        manageTeams mc1 = new manageTeams();
        teams = mc1.getTable();
        readEnrollsJsonFile("src/Model/Enrolls/Enrolls.json");
    }
    @Override
    public ArrayList < Enrolls > readEnrollsJsonFile(String file_path) {
        try {
            JsonNode rootNode = objectMapper.readTree(new File(file_path));

            // Iterate through JSON array
            if (rootNode.isArray()) {
                for (JsonNode node: rootNode) {
                    int t_temp = node.get("t_temp").asInt();
                    int m_temp = node.get("m_temp").asInt();
                    String enroll_date = node.get("enroll_date").asText();
                    int course_fees = node.get("match_entry_fees").asInt();

                    Matches m_temp_obj = null;
                    Teams t_temp_obj = null;

                    for (int i = 0; i < matches.size(); i++) {
                        if (m_temp == matches.get(i).getMatch_ID()) {
                            m_temp_obj = matches.get(i);
                        }
                    }

                    for (int i = 0; i < teams.size(); i++) {
                        if (t_temp == teams.get(i).getTeam_id()) {
                            t_temp_obj = teams.get(i);
                        }
                    }

                    Enrolls e_temp = new Enrolls(t_temp_obj, m_temp_obj, enroll_date, course_fees);
                    enrollment_data.add(e_temp);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return enrollment_data;
    }
    @Override
    public void writeEnrollsJsonFile(String file_path, ArrayList < Enrolls > enroll_al) throws IOException {

        //ArrayList<ArrayList<String>> enroll_to_be_written = new ArrayList<ArrayList<String>>();

        ArrayList < Map < String, Object >> enroll_to_be_written = new ArrayList < > ();

        for (int i = 0; i < enroll_al.size(); i++) {
            HashMap < String, Object > data = new HashMap < > ();
            data.put("t_temp", enroll_al.get(i).getS_temp().getTeam_id());
            data.put("m_temp", enroll_al.get(i).getC_temp().getMatch_ID());
            data.put("enroll_date", enroll_al.get(i).getEnroll_date());
            data.put("match_entry_fees", enroll_al.get(i).getMatch_entry_fees());

            enroll_to_be_written.add(data);
        }

        objectMapper.writeValue(Paths.get(file_path).toFile(), enroll_to_be_written);
    }
    public ArrayList < String > getHeaders() {
        ArrayList < String > headers = new ArrayList < String > ();
        headers.add("Team Name");
        headers.add("Match Id");
        headers.add("Enroll Date");
        headers.add("Match Entry Fees");

        return headers;
    }
    @Override
    public ArrayList < String > getLine(int line) {
        ArrayList < String > game_details = new ArrayList < String > ();

        game_details.add(enrollment_data.get(line).getS_temp().getTeam_name());
        game_details.add(String.valueOf(enrollment_data.get(line).getC_temp().getMatch_ID()));
        game_details.add(enrollment_data.get(line).getEnroll_date());
        game_details.add(String.valueOf(enrollment_data.get(line).getMatch_entry_fees()));

        return game_details;
    }
    @Override
    public ArrayList < ArrayList < String >> getLines(int firstLine, int lastLine) {
        ArrayList < ArrayList < String >> Airline_subset = new ArrayList < ArrayList < String >> ();

        // Check if enrollment_data is empty
        if (!enrollment_data.isEmpty()) {
            for (int i = firstLine; i <= lastLine && i < enrollment_data.size(); i++) {
                Airline_subset.add(getLine(i));
            }
        }

        return Airline_subset;
    }
    @Override
    public int getFirstLineToDisplay() {
        return this.firstLineIndex;
    }
    @Override
    public int getLineToHighlight() {
        return 0;
    }
    @Override
    public int getLastLineToDisplay() {
        setLastLineToDisplay(this.firstLineIndex + this.linesBeingDisplayed - 1);
        return this.lastLineIndex;
    }
    @Override
    public int getLinesBeingDisplayed() {
        return this.linesBeingDisplayed;
    }
    @Override
    public void setFirstLineToDisplay(int firstLine) {
        this.firstLineIndex = firstLine;
    }
    @Override
    public void setLineToHighlight(int highlightedLine) {}
    @Override
    public void setLastLineToDisplay(int lastLine) {
        this.lastLineIndex = lastLine;
    }
    @Override
    public void setLinesBeingDisplayed(int numberOfLines) {
        this.linesBeingDisplayed = numberOfLines;
    }
    public ArrayList < Enrolls > getTable() {
        readEnrollsJsonFile("src/Model/Enrolls/Enrolls.json");
        return enrollment_data;
    }
}