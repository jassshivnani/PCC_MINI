package Model;
import Model.Enrolls.manageEnrolls;
import Model.Matches.manageMatches;
import Model.Teams.manageTeams;
public class Model {
    manageEnrolls me;
    manageMatches mm;
    manageTeams mt;
    public Model(){
        me=new manageEnrolls();
        mm=new manageMatches();
        mt=new manageTeams();
    }
    public void setMe(manageEnrolls me) {
        this.me = me;
    }
    public void setMm(manageMatches mm) {
        this.mm = mm;
    }
    public void setMt(manageTeams mt) {
        this.mt = mt;
    }
    public manageEnrolls getMe() {
        return me;
    }
    public manageMatches getMm() {
        return mm;
    }
    public manageTeams getMt() {
        return mt;
    }
}