package View.Matches;

import javax.swing.*;

public class InitialPanelMatches extends JPanel {

    private MatchesTablePanel ctp;
    private View.Matches.AddMatchesPanel acp;
    private editMatchesPanel emp;
    private deleteMatchesPanel dmp;

    public InitialPanelMatches() {
        super();
        ctp = new MatchesTablePanel();
        add(ctp);
        acp = new View.Matches.AddMatchesPanel();
        add(acp);
        emp = new editMatchesPanel();
        add(emp);
        dmp = new deleteMatchesPanel();
        add(dmp);
    }

    public void setCtp(MatchesTablePanel ctp) {
        this.ctp = ctp;
    }

    public MatchesTablePanel getCtp() {
        return ctp;
    }

    public void setDmp(deleteMatchesPanel dmp) {
        this.dmp = dmp;
    }

    public deleteMatchesPanel getDmp() {
        return dmp;
    }

    public void setEmp(editMatchesPanel emp) {
        this.emp = emp;
    }

    public editMatchesPanel getEmp() {
        return emp;
    }

    public void setAcp(View.Matches.AddMatchesPanel acp) {
        this.acp = acp;
    }

    public View.Matches.AddMatchesPanel getAcp() {
        return acp;
    }
}