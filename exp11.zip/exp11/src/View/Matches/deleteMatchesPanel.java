package View.Matches;

import javax.swing.*;

public class deleteMatchesPanel extends JPanel {
    JTextField txt_match_id;
    JButton deletMatchbtn;
    public deleteMatchesPanel() {
        txt_match_id = new JTextField();
        deletMatchbtn = new JButton("Delete Match");

        txt_match_id.setText("txt_match_id");

        add(txt_match_id);
        add(deletMatchbtn);
    }

    public void setDeletMatchbtn(JButton deletMatchbtn) {
        this.deletMatchbtn = deletMatchbtn;
    }

    public JButton getDeletMatchbtn() {
        return deletMatchbtn;
    }

    public void setTxt_match_id(JTextField txt_match_id) {
        this.txt_match_id = txt_match_id;
    }

    public JTextField getTxt_match_id() {
        return txt_match_id;
    }
}