package View.Matches;

import Model.Model;

import javax.swing.*;

public class editMatchesPanel extends JPanel {
    JTextField txt_get_match_idx;
    JButton getMatchBtn;
    JTextField txt_venue;
    JTextField txt_duration;
    JTextField txt_date;
    JTextField txt_type;
    JButton editMatchBtn;
    Model m1 = new Model();

    public editMatchesPanel() {
        txt_venue = new JTextField();
        txt_duration = new JTextField();
        txt_date = new JTextField();
        txt_type = new JTextField();
        editMatchBtn = new JButton("Edit Course");
        txt_get_match_idx = new JTextField();
        getMatchBtn = new JButton("Get Course to Edit");

        txt_venue.setText("txt_venue");
        txt_duration.setText("txt_duration");
        txt_date.setText("txt_date");
        txt_get_match_idx.setText("get Match id");
        txt_type.setText("txt_type");

        add(txt_get_match_idx);
        add(getMatchBtn);
        add(txt_venue);
        add(txt_duration);
        add(txt_date);
        add(txt_type);
        add(editMatchBtn);
    }

    public void setTxt_type(JTextField txt_type) {
        this.txt_type = txt_type;
    }

    public JTextField getTxt_type() {
        return txt_type;
    }

    public JTextField getTxt_venue() {
        return txt_venue;
    }

    public JTextField getTxt_duration() {
        return txt_duration;
    }

    public JTextField getTxt_date() {
        return txt_date;
    }

    public JButton getEditMatchBtn() {
        return editMatchBtn;
    }

    public JTextField getTxt_get_match_idx() {
        return txt_get_match_idx;
    }
    public JButton getGetMatchBtn() {
        return getMatchBtn;
    }

    public void setTxt_venue(JTextField txt_venue) {
        this.txt_venue = txt_venue;
    }

    public void setTxt_duration(JTextField txt_duration) {
        this.txt_duration = txt_duration;
    }

    public void setTxt_date(JTextField txt_date) {
        this.txt_date = txt_date;
    }

    public void setEditMatchBtn(JButton editMatchBtn) {
        this.editMatchBtn = editMatchBtn;
    }

    public void setTxt_get_match_idx(JTextField txt_get_match_idx) {
        this.txt_get_match_idx = txt_get_match_idx;
    }

    public void setGetMatchBtn(JButton getMatchBtn) {
        this.getMatchBtn = getMatchBtn;
    }
}