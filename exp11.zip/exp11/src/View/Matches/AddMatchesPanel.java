package View.Matches;

import javax.swing.*;

public class AddMatchesPanel extends JPanel {

    JTextField txt_Match_id;
    JTextField txt_venue;
    JTextField txt_match_Duration;
    JTextField txt_match_date;
    JTextField txt_type;
    JButton addCourseBtn;

    public AddMatchesPanel() {

        txt_Match_id = new JTextField();
        txt_venue = new JTextField();
        txt_match_Duration = new JTextField();
        txt_match_date = new JTextField();
        txt_type = new JTextField();
        addCourseBtn = new JButton("Add Match");

        txt_Match_id.setText("txt_Match_id");
        txt_venue.setText("txt_venue");
        txt_match_Duration.setText("txt_match_Duration");
        txt_match_date.setText("txt_match_date");
        txt_type.setText("txt_type");

        add(txt_Match_id);
        add(txt_venue);
        add(txt_match_Duration);
        add(txt_match_date);
        add(txt_type);
        add(addCourseBtn);
    }

    public JTextField getTxt_Match_id() {
        return txt_Match_id;
    }

    public JTextField getTxt_venue() {
        return txt_venue;
    }

    public JTextField getTxt_match_Duration() {
        return txt_match_Duration;
    }

    public JTextField getTxt_match_date() {
        return txt_match_date;
    }

    public JButton getAddCourseBtn() {
        return addCourseBtn;
    }

    public void setTxt_Match_id(JTextField txt_Match_id) {
        this.txt_Match_id = txt_Match_id;
    }

    public void setTxt_venue(JTextField txt_venue) {
        this.txt_venue = txt_venue;
    }

    public void setTxt_match_Duration(JTextField txt_match_Duration) {
        this.txt_match_Duration = txt_match_Duration;
    }

    public void setTxt_match_date(JTextField txt_match_date) {
        this.txt_match_date = txt_match_date;
    }

    public void setAddCourseBtn(JButton addCourseBtn) {
        this.addCourseBtn = addCourseBtn;
    }

    public void setTxt_type(JTextField txt_type) {
        this.txt_type = txt_type;
    }

    public JTextField getTxt_type() {
        return txt_type;
    }
}