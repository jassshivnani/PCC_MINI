package View.Matches;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
public class MatchesTablePanel extends JPanel {
    ArrayList < JButton > course_buttons = new ArrayList < > ();
    public MatchesTablePanel() {
        super();
    }
    public void createButtons(int count) {
        for (int i = 1; i <= count; i++) {
            JButton b = new JButton();
            b.setBackground(Color.cyan);
            b.setSize(500, 50);
            course_buttons.add(b);
            this.add(b);
            validate();
            repaint();
        }
    }
    public void setButtonText(int button_no, String button_text) {
        course_buttons.get(button_no).setText(button_text);
    }
    public ArrayList < JButton > getAllButtons() {
        return course_buttons;
    }
}