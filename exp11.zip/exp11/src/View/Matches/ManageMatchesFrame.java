package View.Matches;

import javax.swing.*;

public class ManageMatchesFrame extends JFrame {
    InitialPanelMatches course_ip;

    public ManageMatchesFrame() {
        super("Manage Matches DashBoard");
        course_ip = new InitialPanelMatches();
        add(course_ip);
        pack();
        setSize(950, 800);
    }

    public void setCourse_ip(InitialPanelMatches course_ip) {
        this.course_ip = course_ip;
    }

    public InitialPanelMatches getCourse_ip() {
        return course_ip;
    }
}