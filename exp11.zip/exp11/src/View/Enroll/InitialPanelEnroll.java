package View.Enroll;

import View.Enroll.AddEnrollPanel;
import View.Enroll.EnrollTablePanel;

import javax.swing.*;

public class InitialPanelEnroll extends JPanel {

    private EnrollTablePanel etp;
    private AddEnrollPanel aep;
    private deleteEnrollPanel dep;

    public InitialPanelEnroll() {
        super();
        etp = new EnrollTablePanel();
        add(etp);
        aep = new AddEnrollPanel();
        add(aep);
        dep = new deleteEnrollPanel();
        add(dep);
    }

    public void setCtp(EnrollTablePanel etp) {
        this.etp = etp;
    }

    public void setDep(deleteEnrollPanel dep) {
        this.dep = dep;
    }

    public deleteEnrollPanel getDep() {
        return dep;
    }

    public EnrollTablePanel getCtap() {
        return etp;
    }

    public void setAcp(AddEnrollPanel aep) {
        this.aep = aep;
    }

    public AddEnrollPanel getAcp() {
        return aep;
    }
}