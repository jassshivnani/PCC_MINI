package View.Enroll;

import javax.swing.*;

public class deleteEnrollPanel extends JPanel {
    JTextField txt_Team_id;
    JTextField txt_match_id;
    JButton deletAirlinebtn;
    public deleteEnrollPanel() {
        txt_Team_id = new JTextField();
        txt_match_id = new JTextField();
        deletAirlinebtn = new JButton("Delete Enrollment");

        txt_Team_id.setText("txt_Team_id");
        txt_match_id.setText("txt_Match_id");

        add(txt_Team_id);
        add(txt_match_id);
        add(deletAirlinebtn);
    }

    public void setDeletAirlinebtn(JButton deletAirlinebtn) {
        this.deletAirlinebtn = deletAirlinebtn;
    }

    public JButton getDeletAirlinebtn() {
        return deletAirlinebtn;
    }

    public void setTxt_Team_id(JTextField txt_Team_id) {
        this.txt_Team_id = txt_Team_id;
    }

    public JTextField getTxt_Team_id() {
        return txt_Team_id;
    }

    public JTextField getTxt_match_id() {
        return txt_match_id;
    }

    public void setTxt_match_id(JTextField txt_match_id) {
        this.txt_match_id = txt_match_id;
    }
}