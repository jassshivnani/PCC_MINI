package View.Enroll;
import javax.swing.*;
public class ManageEnrollFrame extends JFrame {
    InitialPanelEnroll enroll_ip;
    public ManageEnrollFrame()
    {
        super("Manage Enrollments DashBoard");
        enroll_ip = new InitialPanelEnroll();
        add(enroll_ip);
        pack();
        setSize(950, 800);
    }
    public void setEnroll_ip(InitialPanelEnroll enroll_ip) {
        this.enroll_ip = enroll_ip;
    }
    public InitialPanelEnroll getEnroll_ip() {
        return enroll_ip;
    }
}