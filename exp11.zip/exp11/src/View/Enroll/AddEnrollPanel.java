package View.Enroll;

import javax.swing.*;

public class AddEnrollPanel extends JPanel {

    JTextField txt_Match_id;
    JTextField txt_Team_id;
    JTextField txt_enroll_date;
    JTextField txt_match_entry_fees;
    JButton addEnrollBtn;
    public AddEnrollPanel() {

        txt_Match_id = new JTextField();
        txt_Team_id = new JTextField();
        txt_enroll_date = new JTextField();
        txt_match_entry_fees = new JTextField();
        addEnrollBtn = new JButton("Add Enroll");

        txt_Match_id.setText("txt_Match_id");
        txt_Team_id.setText("txt_Team_id");
        txt_enroll_date.setText("txt_enroll_date");
        txt_match_entry_fees.setText("txt_match_entry_fees");

        add(txt_Match_id);
        add(txt_Team_id);
        add(txt_enroll_date);
        add(txt_match_entry_fees);
        add(addEnrollBtn);
    }
    public JTextField getTxt_Match_id() {
        return txt_Match_id;
    }

    public JTextField getTxt_Team_id() {
        return txt_Team_id;
    }

    public JTextField getTxt_enroll_date() {
        return txt_enroll_date;
    }

    public JTextField getTxt_course_fees() {
        return txt_match_entry_fees;
    }

    public JButton getAddEnrollBtn() {
        return addEnrollBtn;
    }

    public void setTxt_Match_id(JTextField txt_Match_id) {
        this.txt_Match_id = txt_Match_id;
    }

    public void setTxt_Team_id(JTextField txt_Team_id) {
        this.txt_Team_id = txt_Team_id;
    }

    public void setTxt_enroll_date(JTextField txt_enroll_date) {
        this.txt_enroll_date = txt_enroll_date;
    }

    public void setTxt_course_fees(JTextField txt_match_entry_fees) {
        this.txt_match_entry_fees = txt_match_entry_fees;
    }

    public void setAddEnrollBtn(JButton addEnrollBtn) {
        this.addEnrollBtn = addEnrollBtn;
    }
}