package View;

import View.Matches.ManageMatchesFrame;
import View.Enroll.ManageEnrollFrame;
import View.Teams.ManageTeamsFrame;

import java.awt.*;
import java.util.ArrayList;
import Model.Model;
public class View {
    FirstFrame ff;
    ManageTeamsFrame msf;

    ManageMatchesFrame mcf;

    ManageEnrollFrame mef;
    Model a = new Model();


    public View()
    {
        ff = new FirstFrame();
        msf = new ManageTeamsFrame();
        mcf = new ManageMatchesFrame();
        mef = new ManageEnrollFrame();
    }

    public void centerInitialSetupStudent(int linesBeingDisplayed, int size) {
        msf.getIp().getCp().setLayout(new GridLayout(linesBeingDisplayed+1,size));
        msf.getIp().getCp().createButtons((linesBeingDisplayed+1) * size);
    }

    public void centerInitialSetupCourse(int linesBeingDisplayed, int size) {
        mcf.getCourse_ip().getCtp().setLayout(new GridLayout(linesBeingDisplayed+1,size));
        mcf.getCourse_ip().getCtp().createButtons((linesBeingDisplayed+1) * size);
    }

    public void centerInitialSetupEnroll(int linesBeingDisplayed, int size) {
        mef.getEnroll_ip().getCtap().setLayout(new GridLayout(linesBeingDisplayed+1,size));
        mef.getEnroll_ip().getCtap().createButtons((linesBeingDisplayed+1) * size);
    }

    public void centerUpdateCourse(ArrayList<ArrayList<String>> lines, ArrayList<String> headers) {
        for (int i = 0; i < headers.size(); i++)
        {
            mcf.getCourse_ip().getCtp().getAllButtons().get(i).setText(headers.get(i));
        }

        for (int course_row_no = 0; course_row_no < lines.size(); course_row_no++)
        {
            for (int course_col_no = 0; course_col_no < headers.size(); course_col_no++)
            {
                int button_no = course_row_no * headers.size() + headers.size() + course_col_no;
                String button_txt = lines.get(course_row_no).get(course_col_no);

                mcf.getCourse_ip().getCtp().getAllButtons().get(button_no).setText(button_txt);
            }
        }
    }


    public void centerUpdateStudent(ArrayList<ArrayList<String>> lines, ArrayList<String> headers) {
        for (int i = 0; i < headers.size(); i++)
        {
            msf.getIp().getCp().getAllButtons().get(i).setText(headers.get(i));
        }

        for (int course_row_no = 0; course_row_no < lines.size(); course_row_no++)
        {
            for (int course_col_no = 0; course_col_no < headers.size(); course_col_no++)
            {
                int button_no = course_row_no * headers.size() + headers.size() + course_col_no;
                String button_txt = lines.get(course_row_no).get(course_col_no);
                msf.getIp().getCp().setButtonText(button_no,button_txt);
            }
        }
    }
    public void centerUpdateEnroll(ArrayList<ArrayList<String>> lines, ArrayList<String> headers) {
        for (int i = 0; i < headers.size(); i++)
        {
            mef.getEnroll_ip().getCtap().getAllButtons().get(i).setText(headers.get(i));
        }

        for (int course_row_no = 0; course_row_no < lines.size(); course_row_no++)
        {
            for (int course_col_no = 0; course_col_no < headers.size(); course_col_no++)
            {
                int button_no = course_row_no * headers.size() + headers.size() + course_col_no;
                String button_txt = lines.get(course_row_no).get(course_col_no);

                mef.getEnroll_ip().getCtap().setButtonText(button_no,button_txt);
            }
        }
    }


    public void setFf(FirstFrame ff) {
        this.ff = ff;
    }

    public FirstFrame getFf() {
        return ff;
    }

    public void setMsf(ManageTeamsFrame msf) {
        this.msf = msf;
    }

    public ManageTeamsFrame getMsf() {
        return msf;
    }

    public void setMcf(ManageMatchesFrame mcf) {
        this.mcf = mcf;
    }

    public ManageMatchesFrame getMcf() {
        return mcf;
    }

    public void setMef(ManageEnrollFrame mef) {
        this.mef = mef;
    }
    public ManageEnrollFrame getMef() {
        return mef;
    }
}