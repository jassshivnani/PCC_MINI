package View.Teams;

import javax.swing.*;

public class InitialPanelTeams extends JPanel {

    private CenterPanelTeams cp;
    private AddPanelTeams aps;
    private editTeamsPanel etp;
    private deleteTeamsPanel dtp;

    public InitialPanelTeams() {
        super();
        cp = new CenterPanelTeams();
        add(cp);
        aps = new AddPanelTeams();
        add(aps);
        etp=new editTeamsPanel();
        add(etp);
        dtp=new deleteTeamsPanel();
        add(dtp);
    }

    public CenterPanelTeams getCp() {
        return cp;
    }

    public deleteTeamsPanel getDtp() {
        return dtp;
    }

    public editTeamsPanel getEtp() {
        return etp;
    }

    public void setDtp(deleteTeamsPanel dtp) {
        this.dtp = dtp;
    }

    public void setEtp(editTeamsPanel etp) {
        this.etp = etp;
    }

    /**
     * @param cp the cp to set
     */
    public void setCp(CenterPanelTeams cp) {
        this.cp = cp;
    }

    public void setAps(AddPanelTeams aps) {
        this.aps = aps;
    }

    public AddPanelTeams getAps() {
        return aps;
    }
}
