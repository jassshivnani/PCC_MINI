package View.Teams;

import javax.swing.*;

public class AddPanelTeams extends JPanel {
    JTextField txt_team_id;
    JTextField txt_team_name;
    JTextField txt_coach;
    JTextField txt_founded_year;
    JTextField txt_Country;
    JButton addStudentBtn;

    public AddPanelTeams(){
        txt_team_id = new JTextField();
        txt_team_name = new JTextField();
        txt_coach = new JTextField();
        txt_founded_year = new JTextField();
        txt_Country = new JTextField();
        addStudentBtn = new JButton("Add Student");

        txt_team_id.setText("team_id");
        txt_team_name.setText("team_name");
        txt_coach.setText("coach");
        txt_founded_year.setText("founded_year");
        txt_Country.setText("Country");

        add(txt_team_id);
        add(txt_team_name);
        add(txt_coach);
        add(txt_founded_year);
        add(txt_Country);
        add(addStudentBtn);
    }



    public JTextField getTxt_team_id() {
        return txt_team_id;
    }

    public JTextField getTxt_team_name() {
        return txt_team_name;
    }

    public JTextField getTxt_founded_year() {
        return txt_founded_year;
    }

    public JTextField getTxt_coach() {
        return txt_coach;
    }

    public JTextField getTxt_Country() {
        return txt_Country;
    }

    public JButton getAddStudentBtn() {
        return addStudentBtn;
    }
}
