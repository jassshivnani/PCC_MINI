package View.Teams;

import javax.swing.*;

public class ManageTeamsFrame extends JFrame {
    InitialPanelTeams ip;

    public ManageTeamsFrame()
    {
        super("Manage Teams DashBoard");
        ip = new InitialPanelTeams();
        add(ip);
        pack();
        setSize(950, 800);
    }

    public void setIp(InitialPanelTeams ip) {
        this.ip = ip;
    }

    public InitialPanelTeams getIp() {
        return ip;
    }
}
