package View.Teams;

import javax.swing.*;

public class deleteTeamsPanel extends JPanel {
    JTextField txt_team_id;
    JButton deletTeambtn;
    public deleteTeamsPanel(){
        txt_team_id=new JTextField();
        deletTeambtn=new JButton("Delete Team");

        txt_team_id.setText("txt_team_id");

        add(txt_team_id);
        add(deletTeambtn);
    }

    public void setDeletTeambtn(JButton deletTeambtn) {
        this.deletTeambtn = deletTeambtn;
    }

    public JButton getDeletTeambtn() {
        return deletTeambtn;
    }

    public void setTxt_team_id(JTextField txt_team_id) {
        this.txt_team_id = txt_team_id;
    }

    public JTextField getTxt_team_id() {
        return txt_team_id;
    }
}
