package View.Teams;

import Model.Model;

import javax.swing.*;

public class editTeamsPanel extends JPanel {
    JTextField txt_get_team_idx;
    JButton getteamBtn;
    JTextField txt_team_Name;
    JTextField txt_coach;
    JTextField txt_year;
    JTextField txt_country;
    JButton editteamBtn;
    Model m1 =new Model();

    public editTeamsPanel()
    {

        txt_team_Name = new JTextField();
        txt_coach = new JTextField();
        txt_year = new JTextField();
        txt_country = new JTextField();
        editteamBtn = new JButton("Edit Course");
        txt_get_team_idx = new JTextField();
        getteamBtn = new JButton("Get Course to Edit");

        txt_team_Name.setText("txt_team_Name");
        txt_coach.setText("txt_coach");
        txt_year.setText("txt_year");
        txt_country.setText("txt_country");
        txt_get_team_idx.setText("get Team id");

        add(txt_get_team_idx);
        add(getteamBtn);
        add(txt_team_Name);
        add(txt_coach);
        add(txt_year);
        add(txt_country);
        add(editteamBtn);
    }

    public JTextField getTxt_team_Name() {
        return txt_team_Name;
    }

    public JTextField getTxt_coach() {
        return txt_coach;
    }

    public JTextField getTxt_year() {
        return txt_year;
    }

    public JTextField getTxt_country() {
        return txt_country;
    }

    public JButton getEditteamBtn() {
        return editteamBtn;
    }

    public JTextField getTxt_get_team_idx() {
        return txt_get_team_idx;
    }
    public JButton getGetteamBtn() {
        return getteamBtn;
    }
    public void setTxt_team_Name(JTextField txt_team_Name) {
        this.txt_team_Name = txt_team_Name;
    }

    public void setTxt_coach(JTextField txt_coach) {
        this.txt_coach = txt_coach;
    }

    public void setTxt_year(JTextField txt_year) {
        this.txt_year = txt_year;
    }

    public void setTxt_country(JTextField txt_country) {
        this.txt_country = txt_country;
    }

    public void setEditteamBtn(JButton editteamBtn) {
        this.editteamBtn = editteamBtn;
    }

    public void setTxt_get_team_idx(JTextField txt_get_team_idx) {
        this.txt_get_team_idx = txt_get_team_idx;
    }

    public void setGetteamBtn(JButton getteamBtn) {
        this.getteamBtn = getteamBtn;
    }
}
