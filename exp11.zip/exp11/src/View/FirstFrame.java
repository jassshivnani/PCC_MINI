package View;

import javax.swing.*;
import java.awt.*;

public class FirstFrame extends JFrame {
    JButton manageStudentBtn;
    JButton manageCourseBtn;
    JButton manageEnrollmentBtn;
    JPanel firstPanel;


    FirstFrame()
    {
        super("Main DashBoard");
        manageStudentBtn = new JButton("Manage Teams");
        manageCourseBtn = new JButton("Manage Matches");
        manageEnrollmentBtn = new JButton("Manage Enrollments");

        firstPanel = new JPanel();
        firstPanel.setLayout(new GridLayout(3,1,20,20));
        firstPanel.add(manageStudentBtn);
        firstPanel.add(manageCourseBtn);
        firstPanel.add(manageEnrollmentBtn);

        add(firstPanel);

        pack();
        setSize(950, 800);
        setVisible(true);
    }

    public void setFirstPanel(JPanel firstPanel) {
        this.firstPanel = firstPanel;
    }

    public void setManageStudentBtn(JButton manageStudentBtn) {
        this.manageStudentBtn = manageStudentBtn;
    }

    public void setManageCourseBtn(JButton manageCourseBtn) {
        this.manageCourseBtn = manageCourseBtn;
    }

    public void setManageEnrollmentBtn(JButton manageEnrollmentBtn) {
        this.manageEnrollmentBtn = manageEnrollmentBtn;
    }

    public JPanel getFirstPanel() {
        return firstPanel;
    }

    public JButton getManageStudentBtn() {
        return manageStudentBtn;
    }

    public JButton getManageCourseBtn() {
        return manageCourseBtn;
    }

    public JButton getManageEnrollmentBtn() {
        return manageEnrollmentBtn;
    }
}
