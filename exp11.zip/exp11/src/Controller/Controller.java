package Controller;

import Model.Model;
import View.View;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;

public class Controller {
    Model model;
    View view;

    public Controller(Model m, View v) {
        model = m;
        view = v;
        view.getFf().getManageEnrollmentBtn().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Enroll Button Clicked");
                view.getFf().setVisible(false);
                view.getMef().setVisible(true);
            }
        });
        view.getMsf().addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                view.getFf().setVisible(true);
            }
        });
        model.getMt().setLinesBeingDisplayed(20);
        view.centerInitialSetupStudent(model.getMt().getLinesBeingDisplayed(), model.getMt().getHeaders().size());

        model.getMt().setFirstLineToDisplay(0);
        view.centerUpdateStudent(model.getMt().getLines(model.getMt().getFirstLineToDisplay(), model.getMt().getLastLineToDisplay()), model.getMt().getHeaders());
        view.getMef().addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                view.getFf().setVisible(true);
            }
        });
        model.getMe().setLinesBeingDisplayed(20);
        view.centerInitialSetupEnroll(model.getMe().getLinesBeingDisplayed(), model.getMe().getHeaders().size());

        model.getMe().setFirstLineToDisplay(0);
        view.centerUpdateEnroll(model.getMe().getLines(model.getMe().getFirstLineToDisplay(), model.getMe().getLastLineToDisplay()), model.getMe().getHeaders());

        view.getFf().getManageCourseBtn().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Course Button Clicked");
                view.getFf().setVisible(false);
                view.getMcf().setVisible(true);
            }
        });
        view.getMcf().getCourse_ip().getCtp().addMouseWheelListener(new MouseWheelListener() {
            @Override
            public void mouseWheelMoved(MouseWheelEvent e) {
                int units = e.getUnitsToScroll();
                System.out.println(units);
                int current_first_line = model.getMm().getFirstLineToDisplay();
                int current_last_line = model.getMm().getLastLineToDisplay();
                int no_of_courses = model.getMm().getTable().size();
                int no_of_display_lines = model.getMm().getLinesBeingDisplayed();
                if (units <= 0 && current_first_line == 0) {
                    model.getMm().setFirstLineToDisplay(0);
                } else if (units <= 0 && current_first_line > 0) {
                    int new_first_line = current_first_line + units;
                    if (new_first_line <= 0) {
                        model.getMm().setFirstLineToDisplay(0);
                    } else {
                        model.getMm().setFirstLineToDisplay(new_first_line);
                    }
                } else if (units > 0 && current_last_line == no_of_courses - 1) {
                    model.getMm().setFirstLineToDisplay(current_first_line);
                } else if (units > 0 && current_last_line < no_of_courses - 1) {
                    int new_first_line = current_first_line + units;
                    if (new_first_line > no_of_courses - no_of_display_lines) {
                        new_first_line = no_of_courses - no_of_display_lines;
                        model.getMm().setFirstLineToDisplay(new_first_line);
                    } else {
                        model.getMm().setFirstLineToDisplay(new_first_line);
                    }
                }

                view.centerUpdateCourse(model.getMm().getLines(model.getMm().getFirstLineToDisplay(), model.getMm().getLastLineToDisplay()), model.getMm().getHeaders());
            }
        });
        view.getMef().getEnroll_ip().getCtap().addMouseWheelListener(new MouseWheelListener() {
            @Override
            public void mouseWheelMoved(MouseWheelEvent e) {
                int units = e.getUnitsToScroll();
                System.out.println(units);
                int current_first_line = model.getMe().getFirstLineToDisplay();
                int current_last_line = model.getMe().getLastLineToDisplay();
                int no_of_courses = model.getMe().getTable().size();
                int no_of_display_lines = model.getMe().getLinesBeingDisplayed();
                if (units <= 0 && current_first_line == 0) {
                    model.getMe().setFirstLineToDisplay(0);
                } else if (units <= 0 && current_first_line > 0) {
                    int new_first_line = current_first_line + units;
                    if (new_first_line <= 0) {
                        model.getMe().setFirstLineToDisplay(0);
                    } else {
                        model.getMe().setFirstLineToDisplay(new_first_line);
                    }
                } else if (units > 0 && current_last_line == no_of_courses - 1) {
                    model.getMe().setFirstLineToDisplay(current_first_line);
                } else if (units > 0 && current_last_line < no_of_courses - 1) {
                    int new_first_line = current_first_line + units;
                    if (new_first_line > no_of_courses - no_of_display_lines) {
                        new_first_line = no_of_courses - no_of_display_lines;
                        model.getMe().setFirstLineToDisplay(new_first_line);
                    } else {
                        model.getMe().setFirstLineToDisplay(new_first_line);
                    }
                }

                view.centerUpdateEnroll(model.getMe().getLines(model.getMe().getFirstLineToDisplay(), model.getMe().getLastLineToDisplay()), model.getMe().getHeaders());
            }
        });
        view.getMsf().getIp().getCp().addMouseWheelListener(new MouseWheelListener() {
            @Override
            public void mouseWheelMoved(MouseWheelEvent e) {
                int units = e.getUnitsToScroll();
                System.out.println(units);
                int current_first_line = model.getMt().getFirstLineToDisplay();
                int current_last_line = model.getMt().getLastLineToDisplay();
                int no_of_courses = model.getMt().getTable().size();
                int no_of_display_lines = model.getMt().getLinesBeingDisplayed();
                if (units <= 0 && current_first_line == 0) {
                    model.getMt().setFirstLineToDisplay(0);
                } else if (units <= 0 && current_first_line > 0) {
                    int new_first_line = current_first_line + units;
                    if (new_first_line <= 0) {
                        model.getMt().setFirstLineToDisplay(0);
                    } else {
                        model.getMt().setFirstLineToDisplay(new_first_line);
                    }
                } else if (units > 0 && current_last_line == no_of_courses - 1) {
                    model.getMt().setFirstLineToDisplay(current_first_line);
                } else if (units > 0 && current_last_line < no_of_courses - 1) {
                    int new_first_line = current_first_line + units;
                    if (new_first_line > no_of_courses - no_of_display_lines) {
                        new_first_line = no_of_courses - no_of_display_lines;
                        model.getMt().setFirstLineToDisplay(new_first_line);
                    } else {
                        model.getMt().setFirstLineToDisplay(new_first_line);
                    }
                }

                view.centerUpdateStudent(model.getMt().getLines(model.getMt().getFirstLineToDisplay(), model.getMt().getLastLineToDisplay()), model.getMt().getHeaders());
            }
        });
        view.getMcf().addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                view.getFf().setVisible(true);
            }
        });

        model.getMm().setLinesBeingDisplayed(20);
        view.centerInitialSetupCourse(model.getMm().getLinesBeingDisplayed(), model.getMm().getHeaders().size());

        model.getMm().setFirstLineToDisplay(0);
        view.centerUpdateCourse(model.getMm().getLines(model.getMm().getFirstLineToDisplay(), model.getMm().getLastLineToDisplay()), model.getMm().getHeaders());
        view.getFf().getManageStudentBtn().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                view.getFf().setVisible(false);
                view.getMsf().setVisible(true);
            }
        });
        view.getMsf().addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                view.getFf().setVisible(true);
            }
        });
    }
}